@extends('Admin.admin_master')
@section('admin')
    <h1>INDEX</h1>
@endsection
