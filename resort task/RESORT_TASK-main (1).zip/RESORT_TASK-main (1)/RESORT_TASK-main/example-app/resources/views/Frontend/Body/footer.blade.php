<footer class="footer_start">
    <div class="container grid top">
        <div class="box">


            <p>Accepted payment methods</p>
            <div class="payment grid">
                <img src="https://img.icons8.com/color/48/000000/visa.png" />
                <img src="https://img.icons8.com/color/48/000000/mastercard.png" />
                <img src="https://img.icons8.com/color-glass/48/000000/paypal.png" />
                <img src="https://img.icons8.com/fluency/48/000000/amex.png" />

            </div>
        </div>

        <div class="box">
            <h3>Recent News</h3>

            <ul>
                <li>New resort has been added</li>
                <li>Live Music Concerts at Luviana</li>
            </ul>
        </div>

        <div class="box">
            <h3>For Customers</h3>
            <ul>
                <li>About Resort</li>
                <li>Help Center</li>
                <li>Terms & Conditions</li>
            </ul>
        </div>

        <div class="box">
            <h3>Contact Us</h3>

            <ul>
                <li>3015 ABC Tower,Dhaka</li>
                <li><i class="far fa-envelope"></i> xyxe@gmail.com </li>
                <li><i class="far fa-phone-alt"></i> 011111111111</li>
                <li><i class="far fa-phone-alt"></i> 08934567 </li>
                <li><i class="far fa-comments"></i> 24/ 7 Services </li>
            </ul>
        </div>
    </div>
</footer>
